from cupy.prof.time_range import time_range  # NOQA
from cupy.prof.time_range import TimeRangeDecorator  # NOQA
