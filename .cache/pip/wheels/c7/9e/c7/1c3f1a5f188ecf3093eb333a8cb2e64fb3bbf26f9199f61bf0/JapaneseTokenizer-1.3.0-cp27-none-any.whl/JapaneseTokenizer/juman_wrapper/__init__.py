__author__ = 'kensuke-mi'
from .juman_wrapper import JumanWrapper
