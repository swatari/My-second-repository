__author__ = 'kensuke-mi'
from .kytea_wrapper import KyteaWrapper