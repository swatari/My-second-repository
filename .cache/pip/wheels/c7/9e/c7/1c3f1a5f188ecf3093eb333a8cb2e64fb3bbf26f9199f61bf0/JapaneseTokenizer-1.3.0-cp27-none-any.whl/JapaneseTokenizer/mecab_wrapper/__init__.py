__author__ = 'kensuke-mi'
from .mecab_wrapper import MecabWrapper
