CHANGES
=======

0.2 (2015-04-02)
------------------

- Change module name jctconv -> jaconv
- Add alphabet and hiragana interconvert (alphabet2kana, kana2alphabet)

0.1.1 (2015-03-12)
------------------

- Support Windows
- Support Python 3.5


0.1 (2014-11-24)
------------------

- Add some Japanese characters to convert table (ゝゞ・「」。、)
- Decresing memory usage
- Some function names are deprecated (hankaku2zenkaku, zenkaku2hankaku, H2K, H2hK, K2H)


0.0.7 (2014-03-22)
------------------

z2h and h2z allow mojimoji-like target character type determination.
Bug fix about Half Kana conversion.

